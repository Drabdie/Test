package com.pixeltuner.app

import java.io.DataOutputStream
import java.io.File

/**
 * Все root-функции — опциональны. Если устройство не рутовано (стоковый Pixel 8
 * с заблокированным загрузчиком), эти вызовы просто вернут false/ничего не сломают.
 * Никакого автоматического получения root — только использование su, если он уже есть.
 */
object RootUtils {

    /** Проверка, есть ли на устройстве su-бинарник и даёт ли он права. */
    fun isRootAvailable(): Boolean {
        val paths = listOf(
            "/system/bin/su", "/system/xbin/su", "/sbin/su",
            "/system/bin/.ext/.su", "/data/adb/magisk/su"
        )
        if (paths.any { File(it).exists() }) return true
        return try {
            val process = ProcessBuilder("su", "-c", "id").start()
            process.waitFor() == 0
        } catch (e: Exception) {
            false
        }
    }

    /** Выполняет список команд от имени root одной сессией su. Возвращает true при успехе. */
    fun runAsRoot(vararg commands: String): Boolean {
        return try {
            val process = ProcessBuilder("su").redirectErrorStream(true).start()
            DataOutputStream(process.outputStream).use { os ->
                commands.forEach { cmd ->
                    os.writeBytes("$cmd\n")
                }
                os.writeBytes("exit\n")
                os.flush()
            }
            process.waitFor() == 0
        } catch (e: Exception) {
            false
        }
    }

    /** Читает системный файл через root (для файлов, недоступных обычному приложению). */
    fun readAsRoot(path: String): String? {
        return try {
            val process = ProcessBuilder("su", "-c", "cat $path").start()
            val result = process.inputStream.bufferedReader().readText().trim()
            process.waitFor()
            if (result.isNotBlank()) result else null
        } catch (e: Exception) {
            null
        }
    }
}
