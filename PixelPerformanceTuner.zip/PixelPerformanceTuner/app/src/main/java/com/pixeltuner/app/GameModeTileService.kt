package com.pixeltuner.app

import android.content.Intent
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Плитка в шторке "Быстрые настройки" — одно касание включает/выключает Extreme-профиль. */
class GameModeTileService : TileService() {

    override fun onClick() {
        super.onClick()
        val prefs = getSharedPreferences("tuner_prefs", MODE_PRIVATE)
        val enabled = !prefs.getBoolean("game_mode_active", false)
        prefs.edit().putBoolean("game_mode_active", enabled).apply()

        qsTile?.state = if (enabled) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        qsTile?.label = if (enabled) "Game Mode: ВКЛ" else "Game Mode: выкл"
        qsTile?.updateTile()

        // Запускаем/останавливаем фоновый монитор, который применит профиль к активной игре
        val serviceIntent = Intent(this, ForegroundMonitorService::class.java)
        if (enabled) startForegroundService(serviceIntent) else stopService(serviceIntent)
    }

    override fun onStartListening() {
        super.onStartListening()
        val active = getSharedPreferences("tuner_prefs", MODE_PRIVATE)
            .getBoolean("game_mode_active", false)
        qsTile?.state = if (active) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        qsTile?.updateTile()
    }
}
