package com.pixeltuner.app

import java.io.File

/**
 * Управление governor'ами CPU. Работает ТОЛЬКО при наличии root.
 * На Tensor G3 (Pixel 8) обычно 9 ядер: cpu0-cpu3 (Cortex-A510, эффективность),
 * cpu4-cpu7 (Cortex-A715/A720, производительность условно), cpu8 (Cortex-X3, самое быстрое).
 * Точные индексы могут отличаться по прошивке — код читает реальное число ядер динамически.
 */
object CpuTweaks {

    fun coreCount(): Int = Runtime.getRuntime().availableProcessors()

    fun availableGovernors(core: Int = 0): List<String> {
        val path = "/sys/devices/system/cpu/cpu$core/cpufreq/scaling_available_governors"
        val fromRoot = RootUtils.readAsRoot(path)
        if (fromRoot != null) return fromRoot.split(" ").filter { it.isNotBlank() }
        return try {
            File(path).readText().trim().split(" ")
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun currentGovernor(core: Int = 0): String? {
        return RootUtils.readAsRoot("/sys/devices/system/cpu/cpu$core/cpufreq/scaling_governor")
            ?: try { File("/sys/devices/system/cpu/cpu$core/cpufreq/scaling_governor").readText().trim() }
            catch (e: Exception) { null }
    }

    /** performance / schedutil / powersave / ondemand — зависит от ядра. */
    fun setGovernorForAllCores(governor: String): Boolean {
        if (!RootUtils.isRootAvailable()) return false
        val commands = (0 until coreCount()).map { core ->
            "echo $governor > /sys/devices/system/cpu/cpu$core/cpufreq/scaling_governor"
        }
        return RootUtils.runAsRoot(*commands.toTypedArray())
    }

    /** Поднимает минимальную частоту всех ядер, чтобы избежать просадок при старте кадра. */
    fun setMinFreqPercentOfMax(percent: Int): Boolean {
        if (!RootUtils.isRootAvailable()) return false
        val commands = mutableListOf<String>()
        for (core in 0 until coreCount()) {
            val maxFreqPath = "/sys/devices/system/cpu/cpu$core/cpufreq/cpuinfo_max_freq"
            val max = RootUtils.readAsRoot(maxFreqPath)?.toIntOrNull() ?: continue
            val target = (max * percent / 100)
            commands.add("echo $target > /sys/devices/system/cpu/cpu$core/cpufreq/scaling_min_freq")
        }
        return RootUtils.runAsRoot(*commands.toTypedArray())
    }

    /** Возвращает governor к рекомендуемому Google дефолту (schedutil) — безопасный откат. */
    fun resetToDefault(): Boolean = setGovernorForAllCores("schedutil")

    fun currentFreqMHz(core: Int): Int? {
        val khz = RootUtils.readAsRoot("/sys/devices/system/cpu/cpu$core/cpufreq/scaling_cur_freq")
            ?.toIntOrNull()
        return khz?.let { it / 1000 }
    }
}
