package com.pixeltuner.app

/**
 * Tensor G3 использует Mali-G715 (не Adreno, поэтому пути отличаются от Snapdragon-твикеров
 * вроде Magic Tuner, которые заточены под /sys/class/kgsl). Пути ниже — типичные для
 * ARM Mali devfreq на актуальных ядрах Pixel; могут отличаться между билдами прошивки.
 * Всё безопасно деградирует, если путь не существует — просто вернёт false.
 */
object GpuTweaks {

    private val candidateDevfreqPaths = listOf(
        "/sys/class/devfreq/13000000.mali",
        "/sys/class/devfreq/mali0",
        "/sys/kernel/gpu/gpu_governor"
    )

    private fun firstExistingPath(): String? {
        for (p in candidateDevfreqPaths) {
            if (RootUtils.readAsRoot("$p/available_governors") != null) return p
        }
        return null
    }

    fun isSupported(): Boolean = RootUtils.isRootAvailable() && firstExistingPath() != null

    /** performance — держит GPU на максимальной частоте (греется, жрёт батарею, минимум фризов). */
    fun setPerformanceGovernor(): Boolean {
        val base = firstExistingPath() ?: return false
        return RootUtils.runAsRoot("echo performance > $base/governor")
    }

    /** simple_ondemand / userspace — сбалансированный режим. */
    fun resetToDefault(): Boolean {
        val base = firstExistingPath() ?: return false
        return RootUtils.runAsRoot("echo simple_ondemand > $base/governor")
    }

    fun currentGovernor(): String? {
        val base = firstExistingPath() ?: return null
        return RootUtils.readAsRoot("$base/governor")
    }
}
