package com.pixeltuner.app

import android.app.Activity
import android.view.Display
import android.view.WindowManager

/**
 * Всё в этом файле работает БЕЗ root — это официальные Android API.
 * Именно этим приложение честнее конкурентов, которые часто просто
 * дергают те же системные флаги под видом "секретных твиков".
 */
object DisplayTweaks {

    /** Принудительно выбирает режим дисплея с максимальной частотой обновления (обычно 120Hz). */
    fun forceHighestRefreshRate(activity: Activity) {
        val display: Display = activity.display ?: return
        val bestMode = display.supportedModes.maxByOrNull { it.refreshRate } ?: return
        val params: WindowManager.LayoutParams = activity.window.attributes
        params.preferredDisplayModeId = bestMode.modeId
        activity.window.attributes = params
    }

    /** Включает "устойчивую производительность" — просит систему не занижать частоты со временем
     *  ради тепла, жертвуя пиком ради стабильности (то, что использует официальный Game Dashboard). */
    fun enableSustainedPerformance(activity: Activity) {
        activity.window.setSustainedPerformanceMode(true)
    }

    fun disableSustainedPerformance(activity: Activity) {
        activity.window.setSustainedPerformanceMode(false)
    }

    fun currentRefreshRate(activity: Activity): Float {
        return activity.display?.refreshRate ?: 60f
    }
}
