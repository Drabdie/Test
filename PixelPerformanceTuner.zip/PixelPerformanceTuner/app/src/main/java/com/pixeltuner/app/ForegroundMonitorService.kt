package com.pixeltuner.app

import android.app.*
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import java.util.concurrent.Executors

/**
 * Определяет запущенное приложение через UsageStatsManager (официальный API, требует
 * ручного разрешения "Доступ к использованию" — Settings.ACTION_USAGE_ACCESS_SETTINGS).
 * Если в списке известных игр — применяет выбранный профиль. Также слушает термальный
 * статус и откатывает твики при перегреве, чтобы не "поджарить" телефон ради лишних FPS.
 */
class ForegroundMonitorService : Service() {

    private val executor = Executors.newSingleThreadScheduledExecutor()
    private val channelId = "tuner_monitor_channel"

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(1, buildNotification("Мониторинг активен"))

        ThermalMonitor.registerListener(applicationContext) { status ->
            if (ThermalMonitor.shouldAutoRevert(status)) {
                // Без Activity root-твики всё равно откатываем напрямую
                CpuTweaks.resetToDefault()
                GpuTweaks.resetToDefault()
            }
        }

        (executor as java.util.concurrent.ScheduledExecutorService).scheduleWithFixedDelay({
            checkForegroundApp()
        }, 0, 5, java.util.concurrent.TimeUnit.SECONDS)
    }

    private fun checkForegroundApp() {
        val pkg = currentForegroundPackage() ?: return
        val prefs = getSharedPreferences("tuner_prefs", MODE_PRIVATE)
        val knownGames = prefs.getStringSet("game_packages", emptySet()) ?: emptySet()
        if (pkg in knownGames) {
            // Применяем твики напрямую (без Activity — только root-часть и governor'ы)
            if (RootUtils.isRootAvailable()) {
                CpuTweaks.setGovernorForAllCores("performance")
                GpuTweaks.setPerformanceGovernor()
            }
        }
    }

    private fun currentForegroundPackage(): String? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return null
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val events = usm.queryEvents(now - 10_000, now)
        var lastPkg: String? = null
        val event = android.app.usage.UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            if (event.eventType == android.app.usage.UsageEvents.Event.MOVE_TO_FOREGROUND) {
                lastPkg = event.packageName
            }
        }
        return lastPkg
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "Pixel Tuner Monitor", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification =
        NotificationCompat.Builder(this, channelId)
            .setContentTitle("Pixel Performance Tuner")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setOngoing(true)
            .build()

    override fun onBind(intent: android.content.Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
        // Безопасный откат при остановке мониторинга
        CpuTweaks.resetToDefault()
        GpuTweaks.resetToDefault()
    }
}
