package com.pixeltuner.app

import android.app.Activity
import android.app.NotificationManager
import android.content.Context

enum class TuningProfile(val displayName: String) {
    EXTREME("Экстрим-производительность"),
    BALANCED("Баланс"),
    BATTERY_SAVER("Экономия батареи"),
}

/**
 * Единая точка применения профиля: собирает root-твики (если есть) и безопасные
 * системные API в одну согласованную операцию, с автоматическим откатом по теплу.
 */
object ProfileManager {

    fun apply(profile: TuningProfile, activity: Activity, silenceNotifications: Boolean) {
        when (profile) {
            TuningProfile.EXTREME -> {
                DisplayTweaks.forceHighestRefreshRate(activity)
                DisplayTweaks.enableSustainedPerformance(activity)
                if (RootUtils.isRootAvailable()) {
                    CpuTweaks.setGovernorForAllCores("performance")
                    CpuTweaks.setMinFreqPercentOfMax(60)
                    GpuTweaks.setPerformanceGovernor()
                }
            }
            TuningProfile.BALANCED -> {
                DisplayTweaks.forceHighestRefreshRate(activity)
                DisplayTweaks.enableSustainedPerformance(activity)
                if (RootUtils.isRootAvailable()) {
                    CpuTweaks.resetToDefault()
                    GpuTweaks.resetToDefault()
                }
            }
            TuningProfile.BATTERY_SAVER -> {
                DisplayTweaks.disableSustainedPerformance(activity)
                if (RootUtils.isRootAvailable()) {
                    CpuTweaks.setGovernorForAllCores("powersave")
                    GpuTweaks.resetToDefault()
                }
            }
        }

        if (silenceNotifications) {
            setDoNotDisturb(activity, enable = profile != TuningProfile.BATTERY_SAVER)
        }
    }

    /** Аварийный откат — вызывается автоматически при перегреве или вручную кнопкой "Паника". */
    fun revertToSafeDefaults(activity: Activity) {
        DisplayTweaks.disableSustainedPerformance(activity)
        if (RootUtils.isRootAvailable()) {
            CpuTweaks.resetToDefault()
            GpuTweaks.resetToDefault()
        }
        setDoNotDisturb(activity, enable = false)
    }

    private fun setDoNotDisturb(context: Context, enable: Boolean) {
        try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (!nm.isNotificationPolicyAccessGranted) return // требует ручного разрешения от юзера
            nm.setInterruptionFilter(
                if (enable) NotificationManager.INTERRUPTION_FILTER_PRIORITY
                else NotificationManager.INTERRUPTION_FILTER_ALL
            )
        } catch (e: Exception) { /* нет доступа — молча пропускаем */ }
    }
}
