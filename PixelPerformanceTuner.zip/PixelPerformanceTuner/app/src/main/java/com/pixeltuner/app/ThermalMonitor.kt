package com.pixeltuner.app

import android.content.Context
import android.os.Build
import android.os.PowerManager

/**
 * Официальный термальный API (Android 10+). Ключевая деталь: если статус доходит до
 * SEVERE/CRITICAL, приложение обязано САМО откатывать агрессивные root-твики — иначе
 * это уже не "превзойти конкурентов", а посадить батарею и ускорить троттлинг.
 */
object ThermalMonitor {

    fun statusLabel(status: Int): String = when (status) {
        PowerManager.THERMAL_STATUS_NONE -> "Норма"
        PowerManager.THERMAL_STATUS_LIGHT -> "Лёгкий нагрев"
        PowerManager.THERMAL_STATUS_MODERATE -> "Умеренный нагрев"
        PowerManager.THERMAL_STATUS_SEVERE -> "Сильный нагрев — троттлинг начался"
        PowerManager.THERMAL_STATUS_CRITICAL -> "Критично — троттлинг максимален"
        PowerManager.THERMAL_STATUS_EMERGENCY -> "Аварийно"
        PowerManager.THERMAL_STATUS_SHUTDOWN -> "Скоро выключение"
        else -> "Неизвестно"
    }

    fun currentStatus(context: Context): Int {
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) pm.currentThermalStatus
        else PowerManager.THERMAL_STATUS_NONE
    }

    fun registerListener(context: Context, onChange: (Int) -> Unit) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        pm.addThermalStatusListener { status -> onChange(status) }
    }

    /** true, если пора откатывать агрессивные твики и защитить железо. */
    fun shouldAutoRevert(status: Int): Boolean =
        status >= PowerManager.THERMAL_STATUS_SEVERE
}
