package com.pixeltuner.app

import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pixeltuner.app.ui.theme.PixelTunerTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PixelTunerTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    TunerScreen(activity = this)
                }
            }
        }
    }
}

@Composable
fun TunerScreen(activity: MainActivity) {
    val context = activity.applicationContext
    var rooted by remember { mutableStateOf(RootUtils.isRootAvailable()) }
    var selectedProfile by remember { mutableStateOf(TuningProfile.BALANCED) }
    var thermalStatus by remember { mutableIntStateOf(ThermalMonitor.currentStatus(context)) }
    var refreshRate by remember { mutableFloatStateOf(DisplayTweaks.currentRefreshRate(activity)) }
    var statusMessage by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        ThermalMonitor.registerListener(context) { status -> thermalStatus = status }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        horizontalAlignment = Alignment.Start
    ) {
        Text("Pixel Performance Tuner", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text("для Pixel 8 · Tensor G3", style = MaterialTheme.typography.bodyMedium)

        Spacer(Modifier.height(20.dp))
        StatusCard(
            rooted = rooted,
            refreshRate = refreshRate,
            thermalLabel = ThermalMonitor.statusLabel(thermalStatus)
        )

        Spacer(Modifier.height(20.dp))
        Text("Профиль производительности", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))

        TuningProfile.values().forEach { profile ->
            ProfileRow(
                profile = profile,
                selected = profile == selectedProfile,
                onSelect = {
                    selectedProfile = profile
                    ProfileManager.apply(profile, activity, silenceNotifications = true)
                    statusMessage = "Применён профиль: ${profile.displayName}"
                }
            )
        }

        Spacer(Modifier.height(20.dp))
        Text("Без root (безопасно, всегда доступно)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Button(onClick = {
            DisplayTweaks.forceHighestRefreshRate(activity)
            refreshRate = DisplayTweaks.currentRefreshRate(activity)
            statusMessage = "Частота обновления экрана максимальна: ${refreshRate}Hz"
        }, modifier = Modifier.fillMaxWidth()) {
            Text("Форсировать макс. частоту экрана")
        }
        Spacer(Modifier.height(8.dp))
        Button(onClick = {
            requestUsageAccess(context)
        }, modifier = Modifier.fillMaxWidth()) {
            Text("Выдать доступ к статистике использования (для авто-профилей игр)")
        }

        Spacer(Modifier.height(20.dp))
        Text(
            if (rooted) "Root обнаружен — доступны глубокие твики CPU/GPU governor."
            else "Root не обнаружен. Глубокие твики CPU/GPU governor недоступны — устройство должно быть с разблокированным загрузчиком и Magisk. Приложение продолжит работать в безопасном режиме на официальных API.",
            style = MaterialTheme.typography.bodySmall
        )

        Spacer(Modifier.height(20.dp))
        Button(
            onClick = {
                ProfileManager.revertToSafeDefaults(activity)
                statusMessage = "Все твики сброшены к безопасным значениям"
            },
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Аварийный сброс (Panic Reset)")
        }

        if (statusMessage.isNotEmpty()) {
            Spacer(Modifier.height(16.dp))
            Text(statusMessage, style = MaterialTheme.typography.bodyMedium)
        }

        Spacer(Modifier.height(24.dp))
        Text(
            "⚠️ Глубокие твики CPU/GPU меняют системные параметры и могут увеличить нагрев, " +
            "снизить время автономной работы и ускорить износ батареи. Приложение автоматически " +
            "откатывает твики при сильном перегреве, но ответственность за использование лежит на вас.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
fun StatusCard(rooted: Boolean, refreshRate: Float, thermalLabel: String) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Root: ${if (rooted) "Доступен" else "Недоступен"}")
            Text("Частота экрана: ${refreshRate}Hz")
            Text("Термальный статус: $thermalLabel")
            Text("Ядер CPU: ${CpuTweaks.coreCount()}")
        }
    }
}

@Composable
fun ProfileRow(profile: TuningProfile, selected: Boolean, onSelect: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
    ) {
        RadioButton(selected = selected, onClick = onSelect)
        Text(profile.displayName, modifier = Modifier.padding(start = 8.dp))
    }
}

private fun requestUsageAccess(context: Context) {
    val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
    val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
    intent.data = Uri.parse("package:${context.packageName}")
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    context.startActivity(intent)
}
